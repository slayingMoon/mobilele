create
    definer = root@localhost procedure udp_get_books_count_by_author(IN first_name varchar(255),
                                                                     IN last_name varchar(255), OUT count_books int)
BEGIN
	select count(b.id) into count_books
	from books b
	join authors a on a.id = b.author_id
	where a.first_name = first_name and a.last_name = last_name;
END;

